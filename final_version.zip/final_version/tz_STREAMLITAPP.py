# import streamlit as st
# import os
# from typing import Dict, Any
# import json
# from datetime import datetime
# import pytz
# from typhoon_SPagent_modify import TyphoonAgent, PLOT_DIR  # Import your main backend code
# from H_datahandle_app import DataHandler

# # Set page configuration
# st.set_page_config(
#     page_title="My AI Chat",
#     page_icon="🌪️",
#     layout="wide",
#     initial_sidebar_state="expanded"
# )

# # Custom CSS
# st.markdown("""
# <style>
#     /* Main background */
#     .main {
#         background-color: #343541;
#         padding-bottom: 80px; /* Space for fixed input container */
#     }
    
#     /* User messages */
#     .user-message {
#         background-color: #40414f;
#         color: #d1d5db;
#         padding: 10px 15px;
#         margin: 10px 0;
#         border-radius: 10px;
#         max-width: 80%;
#         align-self: flex-end;
#         display: inline-block;
#     }
    
#     /* Assistant messages */
#     .assistant-message {
#         background-color: #444654;
#         color: #d1d5db;
#         padding: 10px 15px;
#         margin: 10px 0;
#         border-radius: 10px;
#         max-width: 80%;
#         align-self: flex-start;
#         display: inline-block;
#     }
    
#     /* Message container */
#     .message-container {
#         display: flex;
#         flex-direction: column;
#         margin-bottom: 60px;
#         overflow-y: auto;
#     }
    
#     /* Fixed input container */
#     .fixed-input-container {
#         position: fixed;
#         bottom: 0;
#         left: 0;
#         width: 100%;
#         background-color: #1e1e2f;
#         padding: 10px 15px;
#         display: flex;
#         align-items: center;
#         z-index: 9999;
#         box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.5);
#         border-top: 1px solid #565869;
#     }
    
#     /* Input field */
#     .fixed-input-container input {
#         flex-grow: 1;
#         border: none;
#         outline: none;
#         background: #40414f;
#         color: #fff;
#         font-size: 16px;
#         padding: 10px;
#         border-radius: 20px;
#     }
    
#     /* Send button */
#     .fixed-input-container button {
#         background-color: #565869;
#         border: none;
#         padding: 10px 15px;
#         margin-left: 10px;
#         color: white;
#         border-radius: 20px;
#         cursor: pointer;
#     }
    
#     .fixed-input-container button:hover {
#         background-color: #444654;
        
#     }
# </style>
# """, unsafe_allow_html=True)


# # Initialize session state
# if 'messages' not in st.session_state:
#     st.session_state['messages'] = []

# if 'data_handler' not in st.session_state:
#     st.session_state['data_handler'] = DataHandler({})

# if 'uploaded_files' not in st.session_state:
#     st.session_state['uploaded_files'] = {}

# if 'typhoon_agent' not in st.session_state:
#     st.session_state['typhoon_agent'] = None

# if 'chat_sessions' not in st.session_state:
#     st.session_state['chat_sessions'] = []

# if 'current_session' not in st.session_state:
#     st.session_state['current_session'] = None

# @st.cache_data
# def load_data(file_path):
#     """Load and preprocess data"""
#     data_handler = DataHandler({})
#     file_key = os.path.splitext(os.path.basename(file_path))[0]
#     data_handler.dataset_paths[file_key] = file_path
#     data_handler.load_data()
#     data_handler.preprocess_data()
#     return data_handler

# def initialize_typhoon_agent(dataset_paths):
#     """Initialize or update the TyphoonAgent with new dataset paths"""
#     if st.session_state['typhoon_agent'] is None:
#         st.session_state['typhoon_agent'] = TyphoonAgent(
#             temperature=temperature,
#             base_url="https://api.opentyphoon.ai/v1",
#             model_name="typhoon-v2-70b-instruct",
#             dataset_paths=dataset_paths,
#             dataset_key=next(iter(dataset_paths.keys())) if dataset_paths else ""
#         )
#     else:
#         st.session_state['typhoon_agent'].dataset_paths = dataset_paths
#         st.session_state['typhoon_agent'].dataset_key = next(iter(dataset_paths.keys())) if dataset_paths else ""

# def save_uploaded_file(uploaded_file):
#     """Save uploaded file to temporary directory and return the path"""
#     if uploaded_file is not None:
#         # Create a temporary directory if it doesn't exist
#         if not os.path.exists("temp_uploads"):
#             os.makedirs("temp_uploads")
        
#         file_path = os.path.join("temp_uploads", uploaded_file.name)
#         with open(file_path, "wb") as f:
#             f.write(uploaded_file.getbuffer())
#         return file_path
#     return None


# # ----------------------------------------------------
# #Interface
# # Sidebar with file upload functionality
# with st.sidebar:
#     st.title("⚙️ Chat optional")
#     model_options = {
#             "typhoon-v1.5x": "typhoon-v1.5x-70b-instruct",
#             "typhoon-v2": "typhoon-v2-70b-instruct",
#             "llama-3.3": "meta-llama/Llama-3.3-70B-Instruct-Turbo-Free",
#         }
#     st.selectbox("🦾 Model Settings", model_options)
#     # Temperature slider
#     temperature = st.sidebar.select_slider(
#         'Set temperature',
#         options=[round(i * 0.1, 1) for i in range(0, 11)],
#         value=0.3
#     )
    
#     # File uploader
#     uploaded_file = st.file_uploader(
#         "📂 Upload your dataset (CSV, XLS, XLSX)",
#         type=['csv', 'xls', 'xlsx'],
#         key='file_uploader'
#     )

#     if uploaded_file:
#         file_path = save_uploaded_file(uploaded_file)
#         if file_path:
#             try:
#                 # Load and preprocess data
#                 data_handler = load_data(file_path)
#                 st.session_state['data_handler'] = data_handler
#                 st.session_state['uploaded_files'][os.path.splitext(uploaded_file.name)[0]] = file_path
                
#                 # Initialize or update TyphoonAgent with new dataset paths
#                 initialize_typhoon_agent(st.session_state['uploaded_files'])
                
#                 st.success(f"Successfully loaded {uploaded_file.name}")
#             except Exception as e:
#                 st.error(f"Error loading file: {str(e)}")

#     # Dataset selector (show only uploaded files)
#     if st.session_state['uploaded_files']:
#         selected_dataset = st.selectbox(
#             "Select Dataset",
#             list(st.session_state['uploaded_files'].keys()),
#             index=0
#         )
#         if selected_dataset and st.session_state['typhoon_agent']:
#             st.session_state['typhoon_agent'].dataset_key = selected_dataset

#     # Clear chat button
#     if st.button("Clear Chat"):
#         st.session_state['messages'] = []
#         if st.session_state['typhoon_agent']:
#             st.session_state['typhoon_agent'].clear_memory()
#         st.rerun()

#     # Display dataset info
#     if st.session_state['uploaded_files']:
#         st.subheader("Loaded Datasets")
#         for key in st.session_state['uploaded_files']:
#             try:
#                 df = st.session_state['data_handler'].get_data(key)
#                 st.write(f"**{key}**:")
#                 st.write(f"- Rows: {len(df)}")
#                 st.write(f"- Columns: {len(df.columns)}")
#                 with st.expander(f"Show {key} columns"):
#                     st.write(", ".join(df.columns))
#             except Exception as e:
#                 st.error(f"Error displaying info for {key}: {str(e)}")

#     # #sidebar - chat history
#     # st.sidebar.title("Chat History")
#     # def start_new_session():
#     #     st.session_state.current_session = None
#     # # ปุ่มเริ่มต้นเซสชันใหม่
#     # if st.sidebar.button("Start New Chat"):
#     #     if st.session_state.current_session is not None:
#     #         # บันทึกเซสชันเก่าด้วย title จากข้อความแรก
#     #         if len(st.session_state.chat_sessions[st.session_state.current_session]["history"]) > 0:
#     #             first_message = st.session_state.chat_sessions[st.session_state.current_session]["history"][0]["content"]
#     #             st.session_state.chat_sessions[st.session_state.current_session]["title"] = first_message
#     #         start_new_session()

#     # # แสดงรายการเซสชันใน Sidebar โดยแชทใหม่อยู่ข้างบน
#     # if st.session_state.chat_sessions:
#     #     for idx, session in reversed(list(enumerate(st.session_state.chat_sessions))):
#     #         title = session.get("title", f"Session {idx + 1}")
#     #         if st.sidebar.button(title, key=f"session_{idx}"):
#     #             st.session_state.current_session = idx



# # ----------------------------------------------------
# # Modified handle_submit function
# def handle_submit():
#     user_input = st.session_state['user_input']
#     if user_input.strip() and st.session_state['typhoon_agent']:  # Check if agent exists
#         # Add user message
#         st.session_state['messages'].append({
#             "role": "user",
#             "content": user_input,
#             "timestamp": datetime.now(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
#         })
        
#         try:
#             # Get response from Typhoon Agent
#             response = st.session_state['typhoon_agent'].run(user_input)
            
#             # Add assistant message
#             st.session_state['messages'].append({
#                 "role": "assistant",
#                 "content": response.model_dump(),
#                 "timestamp": datetime.now(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
#             })
#         except Exception as e:
#             st.error(f"Error: {str(e)}")
        
#         # Clear input
#         st.session_state['user_input'] = ""
#     elif not st.session_state['typhoon_agent']:
#         st.warning("Please upload a dataset first before sending messages.")




# # ----------------------------------------------------
# # Main chat interface
# st.title("Data Analysis Chat Assistant")

# # Display chat messages
# for message in st.session_state['messages']:
#     with st.container():
#         if message["role"] == "user":
#             st.markdown(f"""
#             <div class="user-message">
#                 <div style="display: flex; justify-content: space-between;">
#                     <div>🧑‍💻 User: {message["content"]}</div>
#                 </div>
#             </div>
#             """, unsafe_allow_html=True)
#         else:
#             st.markdown(f"""
#             <div class="assistant-message">
#                 <div style="display: flex; justify-content: space-between;">
#                     <div>🤖 Assistant: {message["content"]["response"]}</div>
#                 </div>
#             </div>
#             """, unsafe_allow_html=True)
            
#             # Display code and results if available
#             if "sub_response" in message["content"] and "pandas_agent" in message["content"]["sub_response"]:
#                 pandas_response = message["content"]["sub_response"]["pandas_agent"]
#                 if pandas_response.get("code"):
#                     with st.expander("Show Code"):
#                         st.code(pandas_response["code"], language="python")
                
#                 if "execution_result" in pandas_response:
#                     for plot in pandas_response["execution_result"].get("plots", []):
#                         with st.container():
#                             st.image(os.path.join("static", "plots", plot["filename"]))
                
#                 if pandas_response.get("explanation"):
#                     with st.markdown("See explanation"):
#                         st.write(pandas_response["explanation"].get("explanation", ""))

# # Chat input
# with st.container():
#     st.text_input(
#         "Type your message here...",
#         key='user_input',
#         on_change=handle_submit,
#         disabled=not st.session_state['typhoon_agent']  # Disable if no agent exists
#     )


# part 2
# import streamlit as st
# import os
# from datetime import datetime
# import pytz
# from typhoon_SPagent_modify import TyphoonAgent, PLOT_DIR  # Import your main backend code
# from H_datahandle_app import DataHandler
# import matplotlib.pyplot as plt
# import numpy as np

# # Set page configuration
# st.set_page_config(
#     page_title="My AI Chat",
#     page_icon="🌪️",
#     layout="wide",
#     initial_sidebar_state="expanded"
# )

# # Custom CSS
# st.markdown("""
# <style>
#     /* Main background */
#     .main {
#         background-color: #343541;
#         padding-bottom: 80px; /* Space for fixed input container */
#     }
    
#     /* User messages */
#     .user-message {
#         background-color: #40414f;
#         color: #d1d5db;
#         padding: 10px 15px;
#         margin: 30px 0;
#         border-radius: 10px;
#         max-width: 80%;
#         align-self: flex-end;
#         display: inline-block;
#     }
    
#     /* Message container */
#     .message-container {
#         display: flex;
#         flex-direction: column;
#         margin-bottom: 90px;
#         overflow-y: auto;
#     }
    
#     /* Fixed input container */
#     .fixed-input-container {
#         position: fixed;
#         bottom: 0;
#         left: 0;
#         width: 100%;
#         background-color: #1e1e2f;
#         padding: 10px 15px;
#         display: flex;
#         align-items: center;
#         z-index: 9999;
#         box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.5);
#         border-top: 1px solid #565869;
#     }
    
#     /* Input field */
#     .fixed-input-container input {
#         flex-grow: 1;
#         border: none;
#         outline: none;
#         background: #40414f;
#         color: #fff;
#         font-size: 16px;
#         padding: 10px;
#         border-radius: 20px;
#     }
    
#     /* Send button */
#     .fixed-input-container button {
#         background-color: #565869;
#         border: none;
#         padding: 10px 15px;
#         margin-left: 10px;
#         color: white;
#         border-radius: 20px;
#         cursor: pointer;
#     }
    
#     /* Plot container */
#     .plot-container {
#         width: 20%;  /* Set to 20% of the screen width */
#         margin: 0 auto;  /* Center align the plot */
#     }
# </style>
# """, unsafe_allow_html=True)

# # Initialize session state
# if 'messages' not in st.session_state:
#     st.session_state['messages'] = []

# if 'data_handler' not in st.session_state:
#     st.session_state['data_handler'] = DataHandler({})

# if 'uploaded_files' not in st.session_state:
#     st.session_state['uploaded_files'] = {}

# if 'typhoon_agent' not in st.session_state:
#     st.session_state['typhoon_agent'] = None

# if 'chat_sessions' not in st.session_state:
#     st.session_state['chat_sessions'] = []

# if 'current_session' not in st.session_state:
#     st.session_state['current_session'] = None

# if 'upload_success' not in st.session_state:
#     st.session_state['upload_success'] = False

# @st.cache_data
# def load_data(file_path):
#     """Load and preprocess data"""
#     data_handler = DataHandler({})
#     file_key = os.path.splitext(os.path.basename(file_path))[0]
#     data_handler.dataset_paths[file_key] = file_path
#     data_handler.load_data()
#     data_handler.preprocess_data()
#     return data_handler

# def initialize_typhoon_agent(dataset_paths, temperature):
#     """Initialize or update the TyphoonAgent with new dataset paths"""
#     if st.session_state['typhoon_agent'] is None:
#         st.session_state['typhoon_agent'] = TyphoonAgent(
#             temperature=temperature,
#             base_url="https://api.opentyphoon.ai/v1",
#             model_name="typhoon-v2-70b-instruct",
#             dataset_paths=dataset_paths,
#             dataset_key=next(iter(dataset_paths.keys())) if dataset_paths else ""
#         )
#     else:
#         st.session_state['typhoon_agent'].dataset_paths = dataset_paths
#         st.session_state['typhoon_agent'].dataset_key = next(iter(dataset_paths.keys())) if dataset_paths else ""

# def save_uploaded_file(uploaded_file):
#     """Save uploaded file to temporary directory and return the path"""
#     if uploaded_file is not None:
#         # Create a temporary directory if it doesn't exist
#         if not os.path.exists("temp_uploads"):
#             os.makedirs("temp_uploads")
        
#         file_path = os.path.join("temp_uploads", uploaded_file.name)
#         with open(file_path, "wb") as f:
#             f.write(uploaded_file.getbuffer())
#         return file_path
#     return None

# def start_new_session():
#     """Start a new chat session"""
#     st.session_state['messages'] = []
#     st.session_state['uploaded_files'] = {}
#     st.session_state['typhoon_agent'] = None
#     st.session_state['data_handler'] = DataHandler({})
#     st.session_state['current_session'] = len(st.session_state['chat_sessions'])
#     st.session_state['chat_sessions'].append({
#         'messages': [],
#         'uploaded_files': {},
#         'typhoon_agent': None,
#         'data_handler': DataHandler({})
#     })

# def load_session(session_index):
#     """Load a selected chat session"""
#     # Save the current session state before switching
#     if st.session_state['current_session'] is not None:
#         st.session_state['chat_sessions'][st.session_state['current_session']] = {
#             'messages': st.session_state['messages'],
#             'uploaded_files': st.session_state['uploaded_files'],
#             'typhoon_agent': st.session_state['typhoon_agent'],
#             'data_handler': st.session_state['data_handler']
#         }

#     st.session_state['current_session'] = session_index
#     session_data = st.session_state['chat_sessions'][session_index]
#     st.session_state['messages'] = session_data['messages']
#     st.session_state['uploaded_files'] = session_data['uploaded_files']
#     st.session_state['typhoon_agent'] = session_data['typhoon_agent']
#     st.session_state['data_handler'] = session_data['data_handler']

# def remove_session(session_index):
#     """Remove a selected chat session"""
#     if session_index < len(st.session_state['chat_sessions']):
#         st.session_state['chat_sessions'].pop(session_index)
#         if st.session_state['current_session'] == session_index:
#             st.session_state['current_session'] = None
#             st.session_state['messages'] = []
#             st.session_state['uploaded_files'] = {}
#             st.session_state['typhoon_agent'] = None
#             st.session_state['data_handler'] = DataHandler({})
#         elif st.session_state['current_session'] > session_index:
#             st.session_state['current_session'] -= 1
#         st.success(f"Session {session_index + 1} removed.")
#         # Simulate a rerun
#         st.experimental_rerun()

# # ----------------------------------------------------
# # Sidebar
# with st.sidebar:
#     st.title("⚙️ Chat Configuration")
    
#     # File uploader
#     if not st.session_state['uploaded_files']:
#         st.warning("Please upload a dataset to start.")
#         uploaded_file = st.file_uploader(
#             "📂 Upload your dataset (CSV, XLS, XLSX)",
#             type=['csv', 'xls', 'xlsx'],
#             key='file_uploader'
#         )

#         if uploaded_file:
#             # Start a new session
#             start_new_session()
            
#             file_path = save_uploaded_file(uploaded_file)
#             if file_path:
#                 try:
#                     # Load and preprocess data
#                     data_handler = load_data(file_path)
#                     st.session_state['data_handler'] = data_handler
#                     st.session_state['uploaded_files'][os.path.splitext(uploaded_file.name)[0]] = file_path
                    
#                     # Initialize or update TyphoonAgent with new dataset paths
#                     initialize_typhoon_agent(st.session_state['uploaded_files'], 0.3)  # Default temperature
#                     st.session_state['upload_success'] = True
#                     st.success(f"Successfully loaded {uploaded_file.name}")
#                 except Exception as e:
#                     st.error(f"Error loading file: {str(e)}")
#     else:
#         st.session_state['upload_success'] = True

#     if st.session_state['upload_success']:
#         # Model selection
#         model_options = {
#             "typhoon-v1.5x": "typhoon-v1.5x-70b-instruct",
#             "typhoon-v2": "typhoon-v2-70b-instruct",
#             "llama-3.3": "meta-llama/Llama-3.3-70B-Instruct-Turbo-Free",
#         }
#         st.selectbox("🦾 Model Settings", model_options)
        
#         # Temperature slider
#         temperature = st.select_slider(
#             'Set temperature',
#             options=[round(i * 0.1, 1) for i in range(0, 11)],
#             value=0.3
#         )

#         # Session selector
#         if st.session_state['chat_sessions']:
#             selected_session_index = st.selectbox(
#                 "Select Session",
#                 range(len(st.session_state['chat_sessions'])),
#                 format_func=lambda x: f"Session {x+1}"
#             )
#             if st.button("Load Selected Session"):
#                 load_session(selected_session_index)
#                 st.success(f"Session {selected_session_index + 1} loaded.")

#         # Session removal
#         if st.session_state['chat_sessions']:
#             remove_session_index = st.selectbox(
#                 "Remove Session",
#                 range(len(st.session_state['chat_sessions'])),
#                 format_func=lambda x: f"Session {x+1}"
#             )
#             if st.button("Remove Selected Session"):
#                 remove_session(remove_session_index)

#         # Button to remove the uploaded file
#         if st.session_state['uploaded_files']:
#             if st.button("Remove Uploaded File"):
#                 st.session_state['uploaded_files'] = {}
#                 st.session_state['typhoon_agent'] = None
#                 st.session_state['data_handler'] = DataHandler({})
#                 st.session_state['upload_success'] = False
#                 st.success("Uploaded file removed. Please upload a new file to start.")

#         # Clear chat button
#         if st.button("Clear Chat"):
#             st.session_state['messages'] = []
#             if st.session_state['typhoon_agent']:
#                 st.session_state['typhoon_agent'].clear_memory()
#             # Simulate a rerun
#             st.experimental_rerun()

#         # Display dataset info
#         if st.session_state['uploaded_files']:
#             st.subheader("Loaded Datasets")
#             for key in st.session_state['uploaded_files']:
#                 try:
#                     df = st.session_state['data_handler'].get_data(key)
#                     st.write(f"**{key}**:")
#                     st.write(f"- Rows: {len(df)}")
#                     st.write(f"- Columns: {len(df.columns)}")
#                     with st.expander(f"Show {key} columns"):
#                         st.write(", ".join(df.columns))
#                 except Exception as e:
#                     st.error(f"Error displaying info for {key}: {str(e)}")

# # ----------------------------------------------------
# # Modified handle_submit function
# def handle_submit():
#     user_input = st.session_state['hidden_user_input']
#     if user_input.strip() and st.session_state['typhoon_agent']:  # Check if agent exists
#         # Add user message
#         st.session_state['messages'].append({
#             "role": "user",
#             "content": user_input,
#             "timestamp": datetime.now(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
#         })
        
#         try:
#             # Get response from Typhoon Agent
#             response = st.session_state['typhoon_agent'].run(user_input)
            
#             # Add assistant message
#             st.session_state['messages'].append({
#                 "role": "assistant",
#                 "content": response.model_dump(),
#                 "timestamp": datetime.now(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
#             })
#         except Exception as e:
#             st.error(f"Error: {str(e)}")
        
#         # Clear input
#         st.session_state['hidden_user_input'] = ""

#         # Update the current session with new messages
#         if st.session_state['current_session'] is not None:
#             st.session_state['chat_sessions'][st.session_state['current_session']]['messages'] = st.session_state['messages']
#     elif not st.session_state['typhoon_agent']:
#         st.warning("Please upload a dataset first before sending messages.")

# # ----------------------------------------------------
# # Main chat interface
# st.title("Data Analysis Chat Assistant")

# # Display chat messages
# for message in st.session_state['messages']:
#     with st.container():
#         if message["role"] == "user":
#             st.markdown(f"""
#             <div class="user-message">
#                 <div style="display: flex; justify-content: space-between;">
#                     <div>{message["content"]}</div>
#                 </div>
#             </div>
#             """, unsafe_allow_html=True)
#         else:
#             st.markdown(f"""
#             <div class="assistant-message">
#                 <div style="display: flex; justify-content: space-between;">
#                     <div>🤖 Assistant: {message["content"].get("response", "")}</div>
#                 </div>
#             </div>
#             """, unsafe_allow_html=True)
            
#             # Display code and results if available
#             if "sub_response" in message["content"] and "pandas_agent" in message["content"]["sub_response"]:
#                 pandas_response = message["content"]["sub_response"]["pandas_agent"]
#                 if pandas_response.get("code"):
#                     with st.expander("Show Code"):
#                         st.code(pandas_response["code"], language="python")
                
#                 if "execution_result" in pandas_response:
#                     for plot in pandas_response["execution_result"].get("plots", []):
#                         with st.container():
#                             st.markdown('<div class="plot-container">', unsafe_allow_html=True)
#                             st.image(os.path.join("static", "plots", plot["filename"]), width=800)
#                             st.markdown('</div>', unsafe_allow_html=True)
                
#                 if pandas_response.get("explanation"):
#                     st.markdown("🧑‍🏫Explanation")
#                     st.write(pandas_response["explanation"].get("explanation", ""))

# # Chat input
# input_container = st.empty()
# with input_container.container():
#     st.markdown('<div class="fixed-input-container">', unsafe_allow_html=True)
#     user_input = st.text_input(
#         "Type your message here...",
#         key='hidden_user_input',
#         on_change=handle_submit,
#         placeholder="Type your message and press Enter",
#         label_visibility="collapsed"
#     )
#     st.markdown('</div>', unsafe_allow_html=True)

import streamlit as st
import os
from datetime import datetime
import pytz
from typhoon_SPagent_modify import TyphoonAgent, PLOT_DIR  # Import your main backend code
from H_datahandle_app import DataHandler
import matplotlib.pyplot as plt
import numpy as np

# Set page configuration
st.set_page_config(
    page_title="My AI Chat",
    page_icon="🌪️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    /* Main background */
    .main {
        background-color: #343541;
        padding-bottom: 80px; /* Space for fixed input container */
    }
    
    /* User messages */
    .user-message {
        background-color: #40414f;
        color: #d1d5db;
        padding: 10px 15px;
        margin: 30px 0;
        border-radius: 10px;
        max-width: 80%;
        align-self: flex-end;
        display: inline-block;
    }
    
    /* Message container */
    .message-container {
        display: flex;
        flex-direction: column;
        margin-bottom: 90px;
        overflow-y: auto;
    }
    
    /* Fixed input container */
    .fixed-input-container {
        position: fixed;
        bottom: 0;
        left: 0;
        width: 100%;
        background-color: #1e1e2f;
        padding: 10px 15px;
        display: flex;
        align-items: center;
        z-index: 9999;
        box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.5);
        border-top: 1px solid #565869;
    }
    
    /* Input field */
    .fixed-input-container input {
        flex-grow: 1;
        border: none;
        outline: none;
        background: #40414f;
        color: #fff;
        font-size: 16px;
        padding: 10px;
        border-radius: 20px;
    }
    
    /* Send button */
    .fixed-input-container button {
        background-color: #565869;
        border: none;
        padding: 10px 15px;
        margin-left: 10px;
        color: white;
        border-radius: 20px;
        cursor: pointer;
    }
    
    /* Plot container */
    .plot-container {
        width: 20%;  /* Set to 20% of the screen width */
        margin: 0 auto;  /* Center align the plot */
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state
if 'messages' not in st.session_state:
    st.session_state['messages'] = []
if 'data_handler' not in st.session_state:
    st.session_state['data_handler'] = DataHandler({})
if 'uploaded_files' not in st.session_state:
    st.session_state['uploaded_files'] = {}
if 'typhoon_agent' not in st.session_state:
    st.session_state['typhoon_agent'] = None
if 'chat_sessions' not in st.session_state:
    st.session_state['chat_sessions'] = []
if 'current_session' not in st.session_state:
    st.session_state['current_session'] = None
if 'upload_success' not in st.session_state:
    st.session_state['upload_success'] = False

@st.cache_data
def load_data(file_path):
    """Load and preprocess data"""
    data_handler = DataHandler({})
    file_key = os.path.splitext(os.path.basename(file_path))[0]
    data_handler.dataset_paths[file_key] = file_path
    data_handler.load_data()
    data_handler.preprocess_data()
    return data_handler

def initialize_typhoon_agent(dataset_paths, temperature):
    """Initialize or update the TyphoonAgent with new dataset paths"""
    if st.session_state['typhoon_agent'] is None:
        st.session_state['typhoon_agent'] = TyphoonAgent(
            temperature=temperature,
            base_url="https://api.opentyphoon.ai/v1",
            model_name="typhoon-v2-70b-instruct",
            dataset_paths=dataset_paths,
            dataset_key=next(iter(dataset_paths.keys())) if dataset_paths else ""
        )
    else:
        st.session_state['typhoon_agent'].dataset_paths = dataset_paths
        st.session_state['typhoon_agent'].dataset_key = next(iter(dataset_paths.keys())) if dataset_paths else ""

def save_uploaded_file(uploaded_file):
    """Save uploaded file to temporary directory and return the path"""
    if uploaded_file is not None:
        # Create a temporary directory if it doesn't exist
        if not os.path.exists("temp_uploads"):
            os.makedirs("temp_uploads")
        
        file_path = os.path.join("temp_uploads", uploaded_file.name)
        with open(file_path, "wb") as f:
            f.write(uploaded_file.getbuffer())
        return file_path
    return None

def start_new_session():
    """Start a new chat session"""
    if st.session_state['current_session'] is not None:
        st.session_state['chat_sessions'][st.session_state['current_session']] = {
            'messages': st.session_state['messages'],
            'uploaded_files': st.session_state['uploaded_files'],
            'typhoon_agent': st.session_state['typhoon_agent'],
            'data_handler': st.session_state['data_handler']
        }
    st.session_state['messages'] = []
    st.session_state['uploaded_files'] = {}
    st.session_state['typhoon_agent'] = None
    st.session_state['data_handler'] = DataHandler({})
    st.session_state['current_session'] = len(st.session_state['chat_sessions'])
    st.session_state['chat_sessions'].append({
        'messages': [],
        'uploaded_files': {},
        'typhoon_agent': None,
        'data_handler': DataHandler({})
    })

def load_session(session_index):
    """Load a selected chat session"""
    # Save the current session state before switching
    if st.session_state['current_session'] is not None:
        st.session_state['chat_sessions'][st.session_state['current_session']] = {
            'messages': st.session_state['messages'],
            'uploaded_files': st.session_state['uploaded_files'],
            'typhoon_agent': st.session_state['typhoon_agent'],
            'data_handler': st.session_state['data_handler']
        }

    st.session_state['current_session'] = session_index
    session_data = st.session_state['chat_sessions'][session_index]
    st.session_state['messages'] = session_data['messages']
    st.session_state['uploaded_files'] = session_data['uploaded_files']
    st.session_state['typhoon_agent'] = session_data['typhoon_agent']
    st.session_state['data_handler'] = session_data['data_handler']

def remove_session(session_index):
    """Remove a selected chat session"""
    if session_index < len(st.session_state['chat_sessions']):
        st.session_state['chat_sessions'].pop(session_index)
        if st.session_state['current_session'] == session_index:
            st.session_state['current_session'] = None
            st.session_state['messages'] = []
            st.session_state['uploaded_files'] = {}
            st.session_state['typhoon_agent'] = None
            st.session_state['data_handler'] = DataHandler({})
        elif st.session_state['current_session'] > session_index:
            st.session_state['current_session'] -= 1
        st.success(f"Session {session_index + 1} removed.")
        # Simulate a rerun
        st.experimental_rerun()

# ----------------------------------------------------
# Sidebar
with st.sidebar:
    st.title("⚙️ Chat Configuration")

    # Button to start a new chat session
    if st.button("New Chat"):
        start_new_session()
        st.success("Started a new chat session.")
    
    # File uploader
    if not st.session_state['uploaded_files']:
        st.warning("Please upload a dataset to start.")
        uploaded_file = st.file_uploader(
            "📂 Upload your dataset (CSV, XLS, XLSX)",
            type=['csv', 'xls', 'xlsx'],
            key='file_uploader'
        )

        if uploaded_file:
            # Save the uploaded file
            file_path = save_uploaded_file(uploaded_file)
            if file_path:
                try:
                    # Load and preprocess data
                    data_handler = load_data(file_path)
                    st.session_state['data_handler'] = data_handler
                    st.session_state['uploaded_files'][os.path.splitext(uploaded_file.name)[0]] = file_path
                    
                    # Initialize or update TyphoonAgent with new dataset paths
                    initialize_typhoon_agent(st.session_state['uploaded_files'], 0.3)  # Default temperature
                    st.session_state['upload_success'] = True
                    st.success(f"Successfully loaded {uploaded_file.name}")
                except Exception as e:
                    st.error(f"Error loading file: {str(e)}")
    else:
        st.session_state['upload_success'] = True

    if st.session_state['upload_success']:
        # Model selection
        model_options = {
            "typhoon-v1.5x": "typhoon-v1.5x-70b-instruct",
            "typhoon-v2": "typhoon-v2-70b-instruct",
            "llama-3.3": "meta-llama/Llama-3.3-70B-Instruct-Turbo-Free",
        }
        st.selectbox("🦾 Model Settings", model_options)
        
        # Temperature slider
        temperature = st.select_slider(
            'Set temperature',
            options=[round(i * 0.1, 1) for i in range(0, 11)],
            value=0.3
        )

        # Session selector
        if st.session_state['chat_sessions']:
            selected_session_index = st.selectbox(
                "Select Session",
                range(len(st.session_state['chat_sessions'])),
                format_func=lambda x: f"Session {x+1}"
            )
            if st.button("Load Selected Session"):
                load_session(selected_session_index)
                st.success(f"Session {selected_session_index + 1} loaded.")

        # Session removal
        if st.session_state['chat_sessions']:
            remove_session_index = st.selectbox(
                "Remove Session",
                range(len(st.session_state['chat_sessions'])),
                format_func=lambda x: f"Session {x+1}"
            )
            if st.button("Remove Selected Session"):
                remove_session(remove_session_index)

        # Button to remove the uploaded file
        if st.session_state['uploaded_files']:
            if st.button("Remove Uploaded File"):
                st.session_state['uploaded_files'] = {}
                st.session_state['typhoon_agent'] = None
                st.session_state['data_handler'] = DataHandler({})
                st.session_state['upload_success'] = False
                st.success("Uploaded file removed. Please upload a new file to start.")

        # Clear chat button
        if st.button("Clear Chat"):
            st.session_state['messages'] = []
            if st.session_state['typhoon_agent']:
                st.session_state['typhoon_agent'].clear_memory()
            # Simulate a rerun
            st.experimental_rerun()

        # Display dataset info
        if st.session_state['uploaded_files']:
            st.subheader("Loaded Datasets")
            for key in st.session_state['uploaded_files']:
                try:
                    df = st.session_state['data_handler'].get_data(key)
                    st.write(f"**{key}**:")
                    st.write(f"- Rows: {len(df)}")
                    st.write(f"- Columns: {len(df.columns)}")
                    with st.expander(f"Show {key} columns"):
                        st.write(", ".join(df.columns))
                except Exception as e:
                    st.error(f"Error displaying info for {key}: {str(e)}")

# ----------------------------------------------------
# Modified handle_submit function
def handle_submit():
    user_input = st.session_state['hidden_user_input']
    if user_input.strip() and st.session_state['typhoon_agent']:  # Check if agent exists
        # Add user message
        st.session_state['messages'].append({
            "role": "user",
            "content": user_input,
            "timestamp": datetime.now(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
        })
        
        try:
            # Get response from Typhoon Agent
            response = st.session_state['typhoon_agent'].run(user_input)
            
            # Add assistant message
            st.session_state['messages'].append({
                "role": "assistant",
                "content": response.model_dump(),
                "timestamp": datetime.now(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
            })
        except Exception as e:
            st.error(f"Error: {str(e)}")
        
        # Clear input
        st.session_state['hidden_user_input'] = ""

        # Update the current session with new messages
        if st.session_state['current_session'] is not None:
            st.session_state['chat_sessions'][st.session_state['current_session']]['messages'] = st.session_state['messages']
    elif not st.session_state['typhoon_agent']:
        st.warning("Please upload a dataset first before sending messages.")

# ----------------------------------------------------
# Main chat interface
st.title("Data Analysis Chat Assistant")

# Display chat messages
for message in st.session_state['messages']:
    with st.container():
        if message["role"] == "user":
            st.markdown(f"""
            <div class="user-message">
                <div style="display: flex; justify-content: space-between;">
                    <div>{message["content"]}</div>
                </div>
            </div>
            """, unsafe_allow_html=True)
        else:
            st.markdown(f"""
            <div class="assistant-message">
                <div style="display: flex; justify-content: space-between;">
                    <div>🤖 Assistant: {message["content"].get("response", "")}</div>
                </div>
            </div>
            """, unsafe_allow_html=True)
            
            # Display code and results if available
            if "sub_response" in message["content"] and "pandas_agent" in message["content"]["sub_response"]:
                pandas_response = message["content"]["sub_response"]["pandas_agent"]
                if pandas_response.get("code"):
                    with st.expander("Show Code"):
                        st.code(pandas_response["code"], language="python")
                
                if "execution_result" in pandas_response:
                    for plot in pandas_response["execution_result"].get("plots", []):
                        with st.container():
                            st.markdown('<div class="plot-container">', unsafe_allow_html=True)
                            st.image(os.path.join("static", "plots", plot["filename"]), width=800)
                            st.markdown('</div>', unsafe_allow_html=True)
                
                if pandas_response.get("explanation"):
                    st.markdown("🧑‍🏫Explanation")
                    st.write(pandas_response["explanation"].get("explanation", ""))

# Chat input
input_container = st.empty()
with input_container.container():
    st.markdown('<div class="fixed-input-container">', unsafe_allow_html=True)
    user_input = st.text_input(
        "Type your message here...",
        key='hidden_user_input',
        on_change=handle_submit,
        placeholder="Type your message and press Enter",
        label_visibility="collapsed"
    )
    st.markdown('</div>', unsafe_allow_html=True)